<?php ob_start(); ?>
<?php session_start();
        include_once "./admin/functions.php";
    //    include_once "includes/login.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!--    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
<meta property="og:url"           content="https://www.mychoirsongs.com.ng/index.php" />
<meta property="og:type"          content="website" />
<meta property="og:title"         content="mychoirsongs" />
<meta property="og:description"   content="website to upload and download choir songs including nigerian catholic songs, classicals, folks, psalms liturgical composed songs by different composers and writers" />
<meta property="og:image"         content="https://www.mychoirsongs/img/mychoirsongs logo.jpg" />


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="description" content="website to upload and download choir songs including nigerian catholic songs, classicals, folks, psalms liturgical composed songs by different composers and writers">
    <meta name="keywords" content="mychoirsongs", "choir songs", "psalms", "hymns", "download my choir songs", "litugical songs">

    <meta name="author" content="Silas Ugwu (Ur-world/Ur-net)">
    
    <link rel="icon" href="../img/mcs.png" type="image/x-icon" />

    <title>mychoirsongs</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/blog-home.css" rel="stylesheet">
    <link href="css/stlye.css" rel="stylesheet">
    
<!--        <link href="css/aos.css" rel="stylesheet">-->
<!--    <link href="css/animate.css" rel="stylesheet">-->
<!--    <link href="css/owl.carousel.min.css" rel="stylesheet">-->


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body href="../img/round.png"">
