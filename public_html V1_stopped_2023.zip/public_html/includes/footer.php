
<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v10.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your Chat Plugin code -->
      <div class="fb-customerchat"
        attribution="setup_tool"
        page_id="100782198728317"
  theme_color="#fa3c4c">
      </div>
      
      
<footer  class="col-12 section" >

   <div class="container" >
  <div class="row">
    <div class="col-lg-8">
<!--
<div class="sponsors"><label>Sponsors/Supporters: </label><br/>
     <div class="container">
    <div class="row">
    <div class="col-lg-2">
 <img src="img/spon/headinglogo.jpg" width="100px" height="50px" style="padding-top:0px; padding-left:0px;" />
 </div>
         
         <div class="col-lg-2">
 <img src="img/spon/headinglogo.jpg" width="100px" height="50px" style="padding-top:0px; padding-left:0px;" />
 </div>
       
       <div class="col-lg-2">
 <img src="img/spon/headinglogo.jpg" width="100px" height="50px" style="padding-top:0px; padding-left:0px;" />
 </div>
            <div class="col-lg-2">
 <img src="img/spon/headinglogo.jpg" width="100px" height="50px" style="padding-top:0px; padding-left:0px;" />
 </div>
      </div>
      
    </div></div>
    
-->
    </div>
    <div class="col-lg-4 form-group">
      <?php include_once "sub_email.php"; ?>
    </div>
      
<p class="col-md-6 text-right social">
            <a href="#"><span class="fa fa-tripadvisor"></span></a>
            <a href="#"><span class="fa fa-facebook"></span></a>
            <a href="#"><span class="fa fa-twitter"></span></a>
          </p>
      
  </div>
    <div class="row">
        <div class="col-lg-12">
      <center>
          <p>Copyright &copy; Ur-World 
          
          <script>document.write(new Date().getFullYear());</script>
          </p>
</center>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
       </div>
</footer>


<!-- /.container -->

 
      
<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>


<script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <!-- <script src="js/jquery.waypoints.min.js"></script> -->
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>

 
</body>

</html>
<?php
    /*  ---------------------------------------------------------------------------
     * 	@package	: mychoirsongs
     *	@author 	: Urnet
     *  @email      : emailurworld.net@gmail.com
     *	@version	: 1.0
     *	@link		: http://www.urnet.com.ng
     *	@copyright	: Copyright (c) 2021, http://www.urnet.com.ng
     *	--------------------------------------------------------------------------- */
?>