<div class="col-lg-4">

   

    <!-- login -->
    <div class="well">
<?php if(isset($_SESSION['user_role'])): ?>
<h4><b>Logged in as <small><?php echo $_SESSION['username']; ?></small></b></h4>
  <a href="includes/logout.php" class="btn btn-danger" name="logout">
<span class="glyphicon-log-out">Logout</span>
</a>
<?php else:?>
        <h4>Login</h4>
 
        
         <form action="includes/login.php" method="post">
                <div class="form-group">
                    <input name="username" type="text" class="form-control" placeholder="Enter Username">
                </div>

                  <div class="input-group ">
                    <input name="password" type="password" class="form-control" placeholder="Enter Password">
                    <span class="input-group-btn">
                       <button class="btn btn-primary glyphicon-log-in" name="login" type="submit">Submit
                       </button>
                    </span>
                    
                </div>
                </form>
<?php endif; ?>

        <!-- /.input-group -->
    </div>

    <!-- Blog Categories Well -->
    <div class="well">

<?php
$query = "SELECT * FROM categories";
$select_categories_sidebar = mysqli_query($connection,$query);


?>
        <h4>Categories</h4>
        <div class="row">
            <div class="col-md-6">
                <ul class="list-unstyled" >

        <?php

        while($row = mysqli_fetch_assoc($select_categories_sidebar)) {
        $cat_title = $row['cat_title'];
        $cat_id = $row['cat_id'];

        echo "<li><a href='category.php?category=$cat_id' style='color:#c6164e;'>{$cat_title}</a></li>";
        }

         ?>
                </ul>
            </div>


            <!-- /.col-lg-6 -->
            <div class="col-md-6">
                <ul class="list-unstyled">
                    <li><a href="#">Audios</a>
                    </li>
                    <li><a href="#">Lessons/Training/Lecture</a>
                    </li>
                    <li><a href="#">Composers</a>
                    </li>
                    <li><a href="services.php">Services</a>
                    </li>
                    <li><a href="#">Books</a></li>
                </ul>
            </div>
            <!-- /.col-lg-6 -->


        </div>
        <!-- /.row -->
    </div>

    <!-- Side Widget Well -->
  <?php include "widget.php" ?>

</div>
