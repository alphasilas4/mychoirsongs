<?php ob_start(); ?>
<?php 
//database_connections_1
// $connection = mysqli_connect('localhost','root','','mycms');

// //testing the connection
// if($connection){  echo "we are connected";}

//database_connection_2 using array function for more secured db.
$db['db_host'] = "localhost";
$db['db_user'] = "mychoirs_root";
$db['db_pass'] = "Myaccount4";
$db['db_name'] = "mychoirs_db";

//using uppercase function for each value of the array
foreach ($db as $key => $value) {define(strtoupper($key),$value);}
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

//testing the connection
//if($connection){  echo "we are connected";}

 ?>



<?php
    /*  ---------------------------------------------------------------------------
     * 	@package	: mychoirsongs
     *	@author 	: Urnet
     *  @email      : emailurworld.net@gmail.com
     *	@version	: 1.0
     *	@link		: http://www.urnet.com.ng
     *	@copyright	: Copyright (c) 2021, http://www.urnet.com.ng
     *	--------------------------------------------------------------------------- */
?>