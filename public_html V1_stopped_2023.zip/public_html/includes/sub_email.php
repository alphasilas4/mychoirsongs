
<p>Enter email for News Letters and Updates.</p>
<form class="form-group" role="form" action="" method="post" id="login-form">

  <div class="input-group">
    <input type="email" autocomplete="on" value="<?php echo isset($email)? $email:'' ?>"
     name="email" id="email" class="form-control" placeholder="somebody@example.com">
  <p><?php echo isset($error['email'])? $error['email']:'' ?></p>

       <span class="input-group-btn">
          <button type="submit" class="btn btn-success form-control" name="submit">
  <span>Subscribe</span>
          </button>
      </span>
  </div>
</form>
