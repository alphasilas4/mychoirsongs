<!-- db_connection -->
<?php include "includes/db.php";?>
<!-- header -->
<?php include "includes/header.php";?>

    <!-- Navigation -->
<?php include "includes/navigation.php";?>

 
   
  
   


<!-- Page Content -->
     <div class="container">

         <div class="row">

             <!-- Blog Entries Column -->

             <div class="col-md-8">

     
<p>
<h3>Services</h3> 
    <span>
We also deliver music seminars,staff transcription, trainings, recording, and many more...
    </span>
                 
</p>
                 
                 
                 
                </div>

            <!-- Blog Sidebar Widgets Column -->
 
<?php include "includes/sidebar.php";?>
 
            </div>
</div>
         <!-- /.row -->

        <hr>

        <!-- Footer -->
    <?php include "includes/footer.php";?>
