<div class="well">
 
   <div class="col-ms-4 well">  
    <h6>Follow and  share:</h6>
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your share button code -->
<div class="fb-share-button" 
data-href="https://www.mychoirsongs.com.ng/index.php" 
data-layout="button_count">
</div>
<img src="img/mcslogo.png" width="100px" height="50px" style="padding-right:1px;" />

<br/>
 <h6>Developer</h6> 
    
     <a href="www.urnet.com.ng">
 <img src="img/spon/headinglogo.jpg" width="150px"/>
 </a>
 </div>

</div>
